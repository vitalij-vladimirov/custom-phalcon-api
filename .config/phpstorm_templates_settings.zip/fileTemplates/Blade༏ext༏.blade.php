@extends('layouts.app')

@section('content')
    @include('partials.content-header')
    <div class="content">
        
        <div class="block block-rounded block-bordered">
            <div class="block-header block-header-default">
                <h3 class="block-title">{{ trans('global.title') }}</h3>
            </div>
            <div class="block-content">
                <div class="panel panel-default">
                    <div class="panel-body table-responsive">

                    </div>
                </div>
            </div>
        </div>
        
    </div>
@endsection
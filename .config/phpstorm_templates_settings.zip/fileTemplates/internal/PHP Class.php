<?php
declare(strict_types=1);

#set ( $extend = "" )
#if ( ${NAMESPACE} )
namespace ${NAMESPACE};
    #set ( $namespaces[0] = "" )
    #set ( $namespaces[1] = "" )
    #set ( $namespaces = $NAMESPACE.split("\\") )
    #if ( $namespaces.count > 1 )
        #if ( $namespaces[1] == "Controller" )
            #set ( $extend = "BaseController" )
        #elseif ( $namespaces[1] == "Service" )
            #set ( $extend = "BaseService" )
        #elseif ( $namespaces[1] == "Task" )
            #set ( $extend = "Task" )
        #elseif ( $namespaces[1] == "Config" && ${NAME} == "Routes" )
            #set ( $extend = "BaseRoutes" )
        #end
    #end
    #if ( ${extend} != "" )
        #if ( ${extend} == "BaseController" )
use Common\BaseClasses\BaseController;
        #elseif ( ${extend} == "BaseService" )
use Common\BaseClasses\BaseService;
        #elseif ( ${extend} == "BaseRoutes" )
use Common\BaseClasses\BaseRoutes;
        #elseif ( ${extend} == "Task" )
use Phalcon\Cli\Task;
        #end
    #end
#end

class ${NAME} #if ( ${extend} != "" )
extends ${extend}
#end {
    #if ( ${extend} == "BaseController" || ${extend} == "BaseService" || ${extend} == "BaseRoutes" )
    public function __construct()
    {
        parent::__construct();
    }
    #end
}
